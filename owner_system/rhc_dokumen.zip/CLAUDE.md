# RHC — panduan untuk Claude Code

Bot paper trading sniping memecoin Uniswap v4 di Robinhood Chain (chainId 4663). Pindahan dari PC Windows ke VPS Ubuntu, 19 September 2026. Konteks lengkap: `BACA_DULU.md`, `STRATEGI_FINAL.md`, `DEPLOY_VPS.md`, `CATATAN_AUDIT.md`.

## Cara bicara dengan pemilik
- Bahasa Indonesia, jawab singkat dan langsung ke angka.
- Jelaskan dengan bahasa sederhana kalau diminta ("bahasa SMA").
- Visual/grafik: latar gelap.
- Jangan pernah menyajikan angka simulasi acak (Monte Carlo) sebagai hasil. Pemilik hanya mau hasil dari data on-chain nyata. Kalau terpaksa menyebut proyeksi, labeli jelas sebagai proyeksi.

## Aturan yang tidak boleh dilanggar
- **Mode kertas saja.** Jangan pernah mengirim transaksi uang asli, membuat dompet, atau menyentuh kunci privat.
- **Jangan ubah setelan strategi** (`bot/.env`, aturan masuk/keluar di `v4engine.js`) tanpa diminta pemilik. Setiap perubahan wajib diuji dulu dengan uji maju (`pipeline/wf_penuh.sh`) sebelum dipasang.
- **Tidak boleh melihat masa depan.** Fitur hanya dari data sampai blok keputusan (`init+600`). Model hanya boleh dilatih dari trade yang sudah tutup sebelum koin yang dinilai. Model keluar di tiap periode hanya dilatih dari periode sebelumnya. Jangan menguji model di data latihnya sendiri — kesalahan ini sudah pernah terjadi dan membuat hasil melambung dari $630 palsu.
- **Jangan hardcode alamat kontrak dari ingatan.** Pakai `dok_lama/config.toml` (sudah diverifikasi on-chain).
- **Kunci API di variabel lingkungan**, jangan pernah di-commit (misalnya `BITQUERY_TOKEN`).
- **Jangan hapus trade kalah dari laporan.** Semua trade ikut dihitung.
- **Parameter yang dipilih dengan melihat hasil = overfitting.** Validasi dengan uji silang (pilih di satu periode, buktikan di periode lain).

## Tujuan strategi
Pemilik mengejar **sniping positive-skew** — koin yang naik berkali lipat (1000%+), bukan win rate tinggi. Win rate dan Sharpe bisa menyesatkan di sini. Temuan terbuka: model filter sekarang dilatih dengan label `ret > 1` sehingga menghindari roket (menangkap 2 dari 12 koin >3×). Model pencari roket ada di `pipeline/arena_score_moon.py`, hasilnya belum konsisten.

## Hasil yang berlaku
Uji maju final 2 Ags – 17 Sep, mulai dari nol: **$100 → $12.746,32**, 178 trade, win 75,8%, PF 3,72, drawdown 20,0%, dengan batas posisi 1% likuiditas. Angka lain yang pernah muncul ($2.661, $7.913, $19.401, $23.569) tidak sah — bocor, sintetis, atau sebelum perbaikan audit.

## Struktur
| Folder | Isi |
|---|---|
| `bot/` | `paper_live.js` (bot), `v4engine.js` (mesin, dipakai bot DAN backtest), `filter_feats.js` (34 fitur), `cat_model.js` (skorer CatBoost), 3 model + file `*_check.json`, `.env` |
| `pipeline/` | `collect.js` (unduh data), `replay.js`, `state_rows.js`, `arena.js` (simulasi akun), `arena_score.py` (skor ML kausal), `retrain_filter.py`, `latih_final.py`, `wf_penuh.sh` (uji maju penuh) |
| `data/` | 6 periode utuh + `agustus_mentah/` (berlubang, bisa dilanjutkan dengan checkpoint) |
| `hasil/` | log uji maju final, semua trade, riwayat paper live |

## Perintah
```
cd bot && pm2 start ecosystem.config.js     # jalankan bot
cat bot/status.json                          # equity, posisi, lag_blocks, mode_aman
tail -f bot/live.log                         # setiap koin disaring/dibeli/ditutup
cd pipeline && ./wf_penuh.sh                 # ulang uji maju penuh
```

## Pemeriksaan wajib
- Tiap model punya `*_check.json`; bot menolak jalan kalau prediksi JS meleset > 1e-9 dari Python. Jangan pernah melewati cek ini.
- Setelah mengubah `v4engine.js`, pastikan replay masih identik: `pipeline/replay.js` pada `data/ags4` harus menghasilkan 75 trade yang sama dengan `data/ags4/trades.jsonl`.
- `status.json` → `lag_blocks` harus < 300. Lebih dari itu bot tertinggal dari chain.

## Pekerjaan berikutnya
Lihat `CATATAN_AUDIT.md` bagian "Belum diperbaiki". Yang paling berdampak ke kejujuran angka: penjualan kita belum menggerakkan harga pool, order jual dianggap paling depan dalam blok, belum ada antrean nonce, gas konstan.
